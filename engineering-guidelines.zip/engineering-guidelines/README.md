# Engineering guidelines

A set of 26 engineering guidelines for an embedded R&D function, one guideline per file. It works whether or not products share code. Each has rules with stable IDs, a compliance table, a checklist, and notes for applying it to personal projects and to AI agents.

## Layout

```text
engineering-guidelines/
  README.md
  AGENTS.md              agent instructions to place at the repository root
  CLAUDE.md              imports AGENTS.md for Claude Code
  docs/
    guidelines/
      README.md          index, principles and adoption sequence
      checklists.md      all checklists in one file
      personal-projects.md
      agent-rules.md     condensed rules for AI agents
      principles.md      guiding, architecture, coding, testing and other principles
      core-rules.md      rules that apply to every product
      organisation-adoption.md  two-layer model, roles, cadence and rollout
      eg-001-guidelines-governance.md
      ...
      eg-027-competence-tooling-and-onboarding.md
    templates/
      adr.md  rfc.md  requirement.yaml  nfr-scenario.md
      interface-specification.md  experiment-record.md
      postmortem.md  pull-request-template.md  agent-task-brief.md
      product-conformance-profile.md  component-register.yaml
```

## Install into a project

1. Copy `docs/` and `AGENTS.md` into the repository root. Copy `CLAUDE.md` too if you use Claude Code.
1. For a personal project, read `docs/guidelines/personal-projects.md`. For a team, read `docs/guidelines/README.md`. For several products, read `docs/guidelines/organisation-adoption.md`.
1. Fill in the commands in `AGENTS.md`.
1. Copy `docs/templates/pull-request-template.md` to `.github/pull_request_template.md`.

## Status

All guidelines are `draft` at version 0.1.0 and numeric thresholds are proposals. Set `status: active` in a guideline's front matter when you adopt it.
